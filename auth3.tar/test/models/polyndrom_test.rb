require "test_helper"

class PolyndromTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
