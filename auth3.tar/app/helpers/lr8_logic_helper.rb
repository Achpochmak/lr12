module Lr8LogicHelper
end
